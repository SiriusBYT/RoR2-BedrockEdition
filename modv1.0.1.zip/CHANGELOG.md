
# 1.0.1

- I incorrectly published the mod whoops, fixed now (used to making modpacks, not mods so my bad).

# 1.0.0

- Initial release
