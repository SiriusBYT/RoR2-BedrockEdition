# RoR2 - Bedrock Edition
Adds "Bedrock Edition" below the Risk of Rain 2 Logo, because RoR2 Post-SOTS is literally just that. This mod is compatible both Post and Pre-SOTS, but let's be honest, you'd only use this mod Post-SOTS. Maybe I should make Java Edition for pre-sots lol

Mod forked from SkillIssue2 by sorascode, [repository here](https://github.com/sorascode/SkillIssue2).

![](bg.png "Risk of Rain 2, Bedrock Edition Logo")

### Gearbox Edition version coming out soon maybe

## Changelog

**1.0.1**

* I incorrectly published the mod whoops, fixed now (used to making modpacks, not mods so my bad).

**1.0.0**

* Initial release
